from django.shortcuts import redirect, render
from myApp.models import Student
# Create your views here.

def INDEX(request):
    std = Student.objects.all()
    return render(request, 'index.html', {'std': std})

def ADD(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        address = request.POST.get('address')
        phoneNo = request.POST.get('phoneNo')
        
        std = Student(
            name=name,
            email=email,
            address=address,
            phoneNo=phoneNo
        )
        std.save()
        return redirect('home')
    return render(request, 'index.html')

def EDIT(request):
    std = Student.objects.all()
    return render(request, 'index.html', {'std': std})

def UPDATE(request, id):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        address = request.POST.get('address')
        phoneNo = request.POST.get('phoneNo')
        
        std = Student(
            id = id,
            name=name,
            email=email,
            address=address,
            phoneNo=phoneNo
        )
        std.save()
        return redirect('home')
    return render(request, 'index.html')

def DELETE(request, id):
    std = Student.objects.filter(id = id)
    std.delete()
    return redirect('home')
    return render(request, 'index.html', {'std': std})